#ifndef FINDAWORD_H_INCLUDED
#define FINDAWORD_H_INCLUDED
#include <string>

std::string findAWord();

#endif // FINDAWORD_H_INCLUDED
