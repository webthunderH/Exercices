#ifndef SHAKERHEADER_H_INCLUDED
#define SHAKERHEADER_H_INCLUDED
#include <string>

std::string shaker(std::string word); // il se trouve qu'ici se sont des prototype de fonctions

#endif // SHAKERHEADER_H_INCLUDED
